library(testthat)
library(ggsoccer)

test_check("ggsoccer")
